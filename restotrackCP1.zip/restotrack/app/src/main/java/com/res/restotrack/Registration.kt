package com.res.restotrack

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Registration : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        val username = findViewById<EditText>(R.id.username_r)
        val firstname = findViewById<EditText>(R.id.firstName)
        val lastname = findViewById<EditText>(R.id.lastName)
        val password = findViewById<EditText>(R.id.password_r)
        val confirmpassword = findViewById<EditText>(R.id.confirmpassword)
        val submit = findViewById<Button>(R.id.singup_2)

        submit.setOnClickListener {

            if (username.text.toString().isNullOrEmpty() || firstname.text.toString()
                    .isNullOrEmpty() || lastname.text.toString().isNullOrEmpty()
                || password.text.toString().isNullOrEmpty() || confirmpassword.text.toString()
                    .isNullOrEmpty()
            ) {
                Toast.makeText(this, "Fill out the form completely.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            startActivity(Intent(this, FillLogin::class.java).apply {
             putExtra("username", username.text.toString())
             putExtra("password", password.text.toString())
            }
            )
        }

    }
}