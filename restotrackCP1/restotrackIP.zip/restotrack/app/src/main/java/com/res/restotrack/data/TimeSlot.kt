package com.res.restotrack.data

data class TimeSlot(
    val id: Int,
    val startTime: String,
    val endTime: String
)