package com.res.restotrack

import android.app.Activity
import android.os.Bundle
import android.widget.EditText


class FillLogin : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fill_login)

        val et_username = findViewById<EditText>(R.id.username)
        val et_password = findViewById<EditText>(R.id.password)

        intent?.let{
            it.getStringExtra("username")?.let{username -> et_username.setText(username)}
            it.getStringExtra("password")?.let{password -> et_password.setText(password)}
        }

    }
}